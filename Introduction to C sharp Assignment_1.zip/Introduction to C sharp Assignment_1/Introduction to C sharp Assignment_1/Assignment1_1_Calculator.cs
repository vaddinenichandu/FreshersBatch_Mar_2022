﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Assignment1_Calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            string operand;
            float c = 0;

            while (true)
            {
                Console.WriteLine("Please Enter the a Value: ");
                a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please Enter the b Value: ");
                b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please Choose Operand to perform operation \n (+,-,*,/): ");
                operand = Console.ReadLine();

                switch (operand)
                {
                    case "+":
                        c = a + b;
                        break;
                    case "-":
                        c = a - b;
                        break;
                    case "*":
                        c = a * b;
                        break;
                    case "/":
                        c = a / b;
                        break;
                    default:
                        Console.WriteLine("PLEASE CHOOSE THE CORRECT OPERAND, Thank you:) ");
                        break;
                }
                Console.WriteLine(a.ToString() + " " + operand + " " + b.ToString() + " = " + c.ToString());
                Console.ReadKey();

            }

        }
    }
}
