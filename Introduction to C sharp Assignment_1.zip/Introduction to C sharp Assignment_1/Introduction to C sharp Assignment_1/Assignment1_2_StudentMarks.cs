﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1_2_studentmarks
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int i;
            float sum = 0, average = 0, highest = 0;
            int[] a = new int[5];
            Console.WriteLine("Please Enter marks of Students");

            for (i = 0; i < 5; i++)
            {
                a[i] = int.Parse(Console.ReadLine());

                sum += a[i];
                if (a[i] > highest)
                {
                    highest = a[i];
                }
                average = sum / 5;
            }
            Console.WriteLine("The Average is {0} Highest is {1} ", average, highest);

            Console.ReadLine();

        }
    }
}

