﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Introduction_to_C_sharp_Assignment_1
{
        public class area_circumference
        {
            public static void Main(string[] args)
            {
                double r, AREA;
                const double PI = 3.14;

                Console.Write("\nEnter the radius of circle ");
                r = Convert.ToDouble(Console.ReadLine());
                AREA = PI * r * r;
                Console.WriteLine("\nThe area of circle is {0} when radius is {1}", AREA, r);
                Console.WriteLine("\nThe circumference of circle is {0}", 2 * PI * r);

            }
        }
}
