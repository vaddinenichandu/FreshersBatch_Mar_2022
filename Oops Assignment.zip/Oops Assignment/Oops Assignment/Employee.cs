﻿using System.IO;
using System;


public class Management
{

    private int EmpNo;
    private string EmpName;
    private double Salary, HRA, TA, DA, PF, TDS, NetSalary, GrossSalary;
    public static void Main(string[] args)
    {


        Management program = new Management();
        Console.WriteLine(" Enter the id :");
        program.EmpNo = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter your name : ");
        program.EmpName = Console.ReadLine();

        Console.WriteLine("Enter ur salary : ");
        program.Salary = Convert.ToDouble(Console.ReadLine());
        double grosssalary = program.SetMethod1(program.Salary);
        Console.WriteLine(program.EmpNo + " : " + program.EmpName);
        Console.WriteLine("The gross salary is : " + grosssalary);

        double netsalary = program.CalculateSalary(grosssalary);
        Console.WriteLine("Net Salary is : " + netsalary);

    }
    public double SetMethod1(/*int EmpNum, string Empname,*/ double salary)
    {
        //EmpNo = EmpNum;
        //EmpName = Empname;
        Salary = salary;


        if (Salary < 5000)
        {
            HRA = Salary * 0.1;
            TA = Salary * 0.05;
            DA = Salary * 0.15;
            GrossSalary = Salary + HRA + TA + DA;
            return GrossSalary;
        }

        else if (Salary >= 5000 && Salary < 10000)
        {
            HRA = Salary * 0.15;
            TA = Salary * 0.1;
            DA = Salary * 0.2;
            GrossSalary = Salary + HRA + TA + DA;
            return GrossSalary;
        }

        else if (Salary >= 10000 && Salary < 15000)
        {
            HRA = Salary * 0.2;
            TA = Salary * 0.15;
            DA = Salary * 0.25;
            GrossSalary = Salary + HRA + TA + DA;
            return GrossSalary;
        }

        else if (Salary >= 15000 && Salary < 20000)
        {
            HRA = Salary * 0.25;
            TA = Salary * 0.2;
            DA = Salary * 0.3;
            GrossSalary = Salary + HRA + TA + DA;
            return GrossSalary;
        }

        else if (Salary >= 20000)
        {
            HRA = Salary * 0.3;
            TA = Salary * 0.25;
            DA = Salary * 0.35;
            GrossSalary = Salary + HRA + TA + DA;
            return GrossSalary;
        }



        return GrossSalary;

    }
    public double GetMethod1()
    {
        return GrossSalary;

    }
    public double CalculateSalary(double grosssalary)
    {
        PF = GrossSalary * (0.1);
        TDS = GrossSalary * (0.18);

        NetSalary = GrossSalary - (PF + TDS);
        return NetSalary;
    }


}